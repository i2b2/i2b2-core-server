package com.sun.tools.xjc.reader.relaxng;

import org.kohsuke.rngom.digested.DPatternWalker;

/**
 * Decides the name for a particle.
 * @author Kohsuke Kawaguchi
 */
class NameCalculator extends DPatternWalker {
}
