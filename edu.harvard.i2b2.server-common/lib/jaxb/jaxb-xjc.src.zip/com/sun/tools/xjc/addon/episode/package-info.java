@XmlNamespace(Const.JAXB_NSURI)
package com.sun.tools.xjc.addon.episode;

import com.sun.xml.txw2.annotation.XmlNamespace;
import com.sun.tools.xjc.reader.Const;