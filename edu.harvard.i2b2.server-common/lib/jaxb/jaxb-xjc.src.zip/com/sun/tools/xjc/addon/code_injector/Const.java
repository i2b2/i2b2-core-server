package com.sun.tools.xjc.addon.code_injector;

/**
 * @author Kohsuke Kawaguchi
 */
public class Const {
    /**
     * Customization namespace URI.
     */
    public static final String NS = "http://jaxb.dev.java.net/plugin/code-injector";
}
